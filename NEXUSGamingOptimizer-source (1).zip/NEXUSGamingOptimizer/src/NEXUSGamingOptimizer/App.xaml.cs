namespace NEXUSGamingOptimizer;
public partial class App : System.Windows.Application { }
