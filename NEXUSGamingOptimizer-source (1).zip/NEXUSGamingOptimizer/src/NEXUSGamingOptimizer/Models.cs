using System.Text.Json.Serialization;
namespace NEXUSGamingOptimizer;
public sealed class TweakCard
{
    public string Id { get; set; } = "";
    public string Category { get; set; } = "";
    public string Title { get; set; } = "";
    public string Risk { get; set; } = "";
    public string Status { get; set; } = "";
    public string Description { get; set; } = "";
    public string Purpose { get; set; } = "";
}
public sealed class JournalEntry
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public DateTime Timestamp { get; set; } = DateTime.UtcNow;
    public string TweakId { get; set; } = "";
    public string Name { get; set; } = "";
    public string Action { get; set; } = "";
    public string RegistryPath { get; set; } = "";
    public string ValueName { get; set; } = "";
    public bool ValueExisted { get; set; }
    public string? ValueKind { get; set; }
    public string? OldValue { get; set; }
    public string? NewValue { get; set; }
    public string Result { get; set; } = "";
}
public sealed class HardwareSnapshot
{
    public string Cpu { get; set; } = "Unavailable";
    public string Gpu { get; set; } = "Unavailable";
    public string Windows { get; set; } = "Unavailable";
    public string Ram { get; set; } = "Unavailable";
    public string Disk { get; set; } = "Unavailable";
    public string Display { get; set; } = "Unavailable";
    public string Power { get; set; } = "Unavailable";
    public bool FortniteRunning { get; set; }
    public string FortnitePath { get; set; } = "Not detected";
}
