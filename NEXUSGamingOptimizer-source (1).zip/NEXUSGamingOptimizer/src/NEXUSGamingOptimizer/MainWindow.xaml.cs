using Microsoft.Win32;
using System.Diagnostics;
using System.IO;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace NEXUSGamingOptimizer;

public partial class MainWindow : Window
{
    private List<TweakCard> _cards = new();
    private HardwareSnapshot _snapshot = new();
    private string _currentPage = "Dashboard";
    private readonly JsonSerializerOptions _jsonOptions = new() { WriteIndented = true };

    public MainWindow()
    {
        InitializeComponent();
        try {
            var p=Path.Combine(AppContext.BaseDirectory,"OptimizationCatalog.json");
            _cards=JsonSerializer.Deserialize<List<TweakCard>>(File.ReadAllText(p)) ?? new();
        } catch(Exception ex) { MessageBox.Show("Catalog could not be loaded: "+ex.Message,"NEXUS",MessageBoxButton.OK,MessageBoxImage.Error); }
        AppPaths.Ensure();
        Scan();
        ShowPage("Dashboard");
    }
    private void Nav_Click(object sender, RoutedEventArgs e)
    {
        if(sender is Button b && b.Tag is string tag) ShowPage(tag);
    }
    private void Scan_Click(object sender, RoutedEventArgs e) { Scan(); ShowPage(_currentPage); }
    private void Scan() { _snapshot=SystemInspector.Scan(); StatusBar.Text=$"Scan completed {DateTime.Now:T} • {_cards.Count} catalog cards • no background monitoring"; }
    private void ShowPage(string page)
    {
        _currentPage=page; ContentPanel.Children.Clear(); PageTitle.Text=page;
        PageSubtitle.Text=page=="Dashboard" ? "Detected PC information and honest capability status." : "Review compatibility, risk, current support status, and rollback before changing anything.";
        if(page=="Dashboard") BuildDashboard();
        else if(page=="Quick Optimize") BuildQuickOptimize();
        else if(page=="Restore Center") BuildRestoreCenter();
        else if(page=="Settings and Logs") BuildLogs();
        else if(page=="Profiles") BuildProfiles();
        else if(page=="Fortnite Optimizer") BuildCardList(_cards.Where(x=>x.Category=="Fortnite In-Game Optimization" || x.Title.Contains("Fortnite",StringComparison.OrdinalIgnoreCase)));
        else if(page=="GPU Optimizer") BuildCardList(_cards.Where(x=>x.Category.Contains("GPU") || x.Category.Contains("Radeon") || x.Title.Contains("GPU",StringComparison.OrdinalIgnoreCase)));
        else if(page=="CPU Optimizer") BuildCardList(_cards.Where(x=>x.Category.Contains("CPU") || x.Category.Contains("Power and Thermal")));
        else if(page=="Windows Optimizer") BuildCardList(_cards.Where(x=>x.Category=="Windows Gaming and Graphics" || x.Category=="Registry Optimization and Recovery"));
        else if(page=="Network and Online Latency") BuildCardList(_cards.Where(x=>x.Category==page));
        else if(page=="Startup and Background Applications") BuildCardList(_cards.Where(x=>x.Category==page));
        else if(page=="Registry Optimization and Recovery") BuildCardList(_cards.Where(x=>x.Category==page));
        else if(page=="Profiles, Monitoring, and Session Management") BuildCardList(_cards.Where(x=>x.Category==page));
        else if(page=="All Tweaks") BuildCardList(_cards);
        else BuildCardList(_cards);
    }
    private void BuildDashboard()
    {
        var top=new WrapPanel();
        AddMetric(top,"CPU",_snapshot.Cpu); AddMetric(top,"GPU",_snapshot.Gpu); AddMetric(top,"RAM",_snapshot.Ram);
        AddMetric(top,"Windows",_snapshot.Windows); AddMetric(top,"Display",_snapshot.Display); AddMetric(top,"Disk free space",_snapshot.Disk);
        AddMetric(top,"Active power plan",_snapshot.Power); AddMetric(top,"Fortnite",_snapshot.FortniteRunning?"RUNNING":_snapshot.FortnitePath);
        ContentPanel.Children.Add(top);
        AddHeader("System checks");
        AddText($"Fortnite process running: {_snapshot.FortniteRunning}");
        AddText($"Detected Fortnite executable: {_snapshot.FortnitePath}");
        AddText($"Game DVR capture preference: {SafeTweakService.ReadCaptureState()}");
        AddText($"Network interfaces: {string.Join(", ", System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces().Where(n=>n.OperationalStatus==System.Net.NetworkInformation.OperationalStatus.Up).Select(n=>n.Name+" ("+n.NetworkInterfaceType+")"))}");
        AddHeader("Measurement honesty");
        AddText("Live FPS, 1% lows, 0.1% lows, frame-time charts, temperatures, and input latency are not collected in this build. They are not replaced with estimates or fake values.");
        AddText("Current implementation is a safe starter release: hardware/status inspection, a 120-card catalog, selected reversible per-user capture setting, journal, local report export, profile metadata, and guided procedures.");
        var row=new StackPanel { Orientation=Orientation.Horizontal, Margin=new Thickness(0,8,0,0) };
        row.Children.Add(MakeButton("Open Quick Optimize",()=>ShowPage("Quick Optimize")));
        row.Children.Add(MakeButton("Review all 120 cards",()=>ShowPage("All Tweaks")));
        ContentPanel.Children.Add(row);
    }
    private void AddMetric(Panel panel,string title,string value)
    {
        var border=new Border { Width=300, MinHeight=105, Margin=new Thickness(0,0,12,12), Padding=new Thickness(14), CornerRadius=new CornerRadius(8), Background=(Brush)FindResource("Panel"), BorderBrush=new SolidColorBrush(Color.FromRgb(48,58,77)), BorderThickness=new Thickness(1) };
        var stack=new StackPanel(); stack.Children.Add(new TextBlock{Text=title.ToUpperInvariant(),Foreground=(Brush)FindResource("Muted"),FontSize=11,Margin=new Thickness(0,0,0,7)});
        stack.Children.Add(new TextBlock{Text=value,FontSize=14,TextWrapping=TextWrapping.Wrap}); border.Child=stack; panel.Children.Add(border);
    }
    private void BuildQuickOptimize()
    {
        AddHeader("Safe Optimize");
        AddText("This scan recommends only supported actions. Nothing is changed automatically. Review the effect and confirm any action.");
        AddText("Current Game DVR / background capture preference: "+SafeTweakService.ReadCaptureState());
        var panel=new StackPanel { Orientation=Orientation.Horizontal };
        panel.Children.Add(MakeButton("Disable per-user capture",()=>ConfirmCapture(false)));
        panel.Children.Add(MakeButton("Enable per-user capture",()=>ConfirmCapture(true)));
        panel.Children.Add(MakeButton("Undo latest capture change",()=>{var r=MessageBox.Show("Restore the last app-managed original value? External changes will be protected.","Confirm rollback",MessageBoxButton.YesNo,MessageBoxImage.Warning); if(r==MessageBoxResult.Yes) MessageBox.Show(SafeTweakService.UndoLatestCapture());}));
        ContentPanel.Children.Add(panel);
        AddHeader("Recommended review");
        foreach(var c in _cards.Where(c=>c.Risk=="Low").Take(12)) AddCard(c);
        AddHeader("Important limitations");
        AddText("No registry bundle, boot tweak, service disabling, security feature disabling, forced affinity, or automatic overclocking is performed. A recommendation is not a guarantee of FPS improvement.");
    }
    private void ConfirmCapture(bool enabled)
    {
        if(_snapshot.FortniteRunning) { var res=MessageBox.Show("Fortnite appears to be running. Apply this per-user capture preference anyway? A restart may be needed for some apps.","Game running",MessageBoxButton.YesNo,MessageBoxImage.Warning); if(res!=MessageBoxResult.Yes)return; }
        var ask=MessageBox.Show($"Change the current-user AppCaptureEnabled preference to {(enabled?"1 (enabled)":"0 (disabled)")}?\n\nThe current value will be journaled for rollback. This may not control every Windows capture feature.","Confirm setting change",MessageBoxButton.YesNo,MessageBoxImage.Warning);
        if(ask!=MessageBoxResult.Yes)return;
        try { MessageBox.Show(SafeTweakService.ToggleCapture(enabled),"NEXUS",MessageBoxButton.OK,MessageBoxImage.Information); Scan(); ShowPage(_currentPage); }
        catch(Exception ex) { MessageBox.Show("Change failed: "+ex.Message,"NEXUS",MessageBoxButton.OK,MessageBoxImage.Error); }
    }
    private void BuildCardList(IEnumerable<TweakCard> cards)
    {
        var search=new TextBox { Height=34, Margin=new Thickness(0,0,0,12), Padding=new Thickness(8), Background=new SolidColorBrush(Color.FromRgb(25,29,39)), Foreground=Brushes.White, BorderBrush=new SolidColorBrush(Color.FromRgb(59,74,98)), ToolTip="Filter by title, category, status, risk, or explanation" };
        search.TextChanged += (_,_) => { ContentPanel.Children.Clear(); ContentPanel.Children.Add(search); foreach(var c in cards.Where(c=>(c.Title+" "+c.Category+" "+c.Status+" "+c.Risk+" "+c.Description).Contains(search.Text,StringComparison.OrdinalIgnoreCase))) AddCard(c); };
        ContentPanel.Children.Add(search);
        foreach(var c in cards) AddCard(c);
    }
    private void AddCard(TweakCard c)
    {
        var border=new Border { Background=(Brush)FindResource("Panel"), BorderBrush=new SolidColorBrush(Color.FromRgb(48,58,77)), BorderThickness=new Thickness(1), CornerRadius=new CornerRadius(8), Padding=new Thickness(14), Margin=new Thickness(0,0,0,10) };
        var stack=new StackPanel();
        var header=new DockPanel();
        var status=new TextBlock { Text=$"{c.Risk.ToUpperInvariant()}  •  {c.Status}", Foreground=c.Risk=="Advanced"?Brushes.Orange:(Brush)FindResource("Accent"), FontSize=11, TextWrapping=TextWrapping.Wrap };
        DockPanel.SetDock(status,Dock.Right); header.Children.Add(status);
        header.Children.Add(new TextBlock{Text=$"{c.Id}  {c.Title}",FontSize=17,FontWeight=FontWeights.SemiBold,TextWrapping=TextWrapping.Wrap});
        stack.Children.Add(header); stack.Children.Add(new TextBlock{Text=c.Category,Foreground=(Brush)FindResource("Muted"),Margin=new Thickness(0,5,0,5)});
        stack.Children.Add(new TextBlock{Text=c.Description,TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,0,0,6)});
        stack.Children.Add(new TextBlock{Text="Purpose: "+c.Purpose,TextWrapping=TextWrapping.Wrap,Foreground=(Brush)FindResource("Muted")});
        var row=new StackPanel { Orientation=Orientation.Horizontal, Margin=new Thickness(0,8,0,0) };
        if(c.Title=="Background Game DVR" || c.Title=="Background Capture" || c.Title=="Game DVR Capture Toggle")
        {
            row.Children.Add(MakeButton("Apply: disable capture",()=>ConfirmCapture(false)));
            row.Children.Add(MakeButton("Undo last capture change",()=>{var r=MessageBox.Show("Restore the saved original value?","Confirm rollback",MessageBoxButton.YesNo);if(r==MessageBoxResult.Yes)MessageBox.Show(SafeTweakService.UndoLatestCapture());}));
        }
        if(c.Title=="Fortnite Configuration Backup") row.Children.Add(MakeButton("Back up config",BackupFortniteConfig));
        if(c.Title=="Fortnite Configuration Restore") row.Children.Add(MakeButton("Restore latest app backup",RestoreFortniteConfig));
        if(c.Title=="Diagnostic Report Export" || c.Title=="Configuration Snapshot") row.Children.Add(MakeButton("Export report",ExportReport));
        if(c.Title=="Power Profile Backup") row.Children.Add(MakeButton("Export active power plan",BackupPower));
        if(c.Title=="Power Profile Restore") row.Children.Add(MakeButton("Restore latest power backup",RestorePower));
        if(c.Title=="Startup Application Manager") row.Children.Add(MakeButton("Inspect startup entries",()=>MessageBox.Show(SystemInspector.StartupSummary(),"Startup inventory")));
        if(c.Title=="Background Process Review") row.Children.Add(MakeButton("Inspect top processes",()=>MessageBox.Show(SystemInspector.ProcessSummary(),"Process snapshot")));
        if(c.Title=="Ping, Jitter, and Packet-Loss Testing") row.Children.Add(MakeButton("Run ping test",RunPing));
        if(c.Title=="Fortnite File Verification") row.Children.Add(MakeButton("Open Epic Launcher",OpenEpic));
        if(row.Children.Count>0) stack.Children.Add(row);
        border.Child=stack; ContentPanel.Children.Add(border);
    }
    private Button MakeButton(string text,Action action) { var b=new Button{Content=text}; b.Click+=(_,_)=>{try{action();}catch(Exception ex){MessageBox.Show(ex.Message,"NEXUS",MessageBoxButton.OK,MessageBoxImage.Error);}}; return b; }
    private void AddHeader(string s) => ContentPanel.Children.Add(new TextBlock{Text=s,FontSize=20,FontWeight=FontWeights.SemiBold,Margin=new Thickness(0,16,0,8)});
    private void AddText(string s) => ContentPanel.Children.Add(new TextBlock{Text=s,FontSize=13,Foreground=(Brush)FindResource("Muted"),TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,3,0,7)});
    private void BackupFortniteConfig()
    {
        var path=FindFortniteConfig(); if(path==null){MessageBox.Show("Fortnite GameUserSettings.ini was not found in the default local config folder. Custom Windows profiles may use a different path.");return;}
        Directory.CreateDirectory(AppPaths.Backups); var target=Path.Combine(AppPaths.Backups,"GameUserSettings-"+DateTime.Now.ToString("yyyyMMdd-HHmmss")+".ini.bak"); File.Copy(path,target,true); MessageBox.Show("Backup created:\n"+target);
    }
    private string? FindFortniteConfig()
    {
        var p=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"FortniteGame","Saved","Config","WindowsClient","GameUserSettings.ini");
        return File.Exists(p)?p:null;
    }
    private void RestoreFortniteConfig()
    {
        var files=Directory.GetFiles(AppPaths.Backups,"GameUserSettings-*.ini.bak").OrderByDescending(File.GetLastWriteTimeUtc).ToArray();
        if(files.Length==0){MessageBox.Show("No app-created Fortnite configuration backup was found.");return;}
        var path=FindFortniteConfig(); if(path==null){MessageBox.Show("Current Fortnite config was not found.");return;}
        if(MessageBox.Show("Restore this backup?\n"+files[0]+"\n\nThe current config will first be copied aside.","Confirm restore",MessageBoxButton.YesNo,MessageBoxImage.Warning)!=MessageBoxResult.Yes)return;
        File.Copy(path,path+".before-nexus-"+DateTime.Now.ToString("yyyyMMdd-HHmmss")+".bak",true); File.Copy(files[0],path,true); MessageBox.Show("Configuration restored. This does not change settings currently held in game memory.");
    }
    private void ExportReport()
    {
        var report=$"NEXUS Gaming Optimizer diagnostic report\nGenerated: {DateTime.Now:O}\n\nCPU: {_snapshot.Cpu}\nGPU: {_snapshot.Gpu}\nWindows: {_snapshot.Windows}\nRAM: {_snapshot.Ram}\nDisk: {_snapshot.Disk}\nDisplay: {_snapshot.Display}\nPower: {_snapshot.Power}\nFortnite running: {_snapshot.FortniteRunning}\nFortnite path: {_snapshot.FortnitePath}\nCapture preference: {SafeTweakService.ReadCaptureState()}\n\nCatalog cards: {_cards.Count}\nImplemented FPS/frame-time capture: No\nNo FPS gain is claimed by this report.\n\nJournal:\n{string.Join(Environment.NewLine,LocalStore.ReadJournal().Select(x=>$"{x.Timestamp:O} | {x.Name} | {x.Action} | {x.Result}"))}";
        var target=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory),"NEXUS-Diagnostic-"+DateTime.Now.ToString("yyyyMMdd-HHmmss")+".txt"); File.WriteAllText(target,report); MessageBox.Show("Report exported:\n"+target);
    }
    private void BackupPower()
    {
        var psi=new ProcessStartInfo("powercfg.exe",$"/getactivescheme") { RedirectStandardOutput=true,UseShellExecute=false,CreateNoWindow=true };
        using var p=Process.Start(psi); var output=p?.StandardOutput.ReadToEnd()??""; p?.WaitForExit();
        var m=System.Text.RegularExpressions.Regex.Match(output,@"[0-9a-fA-F-]{36}");
        if(!m.Success){MessageBox.Show("Could not determine active power scheme.");return;}
        var file=Path.Combine(AppPaths.Backups,"power-"+DateTime.Now.ToString("yyyyMMdd-HHmmss")+".pow");
        var exp=Process.Start(new ProcessStartInfo("powercfg.exe",$"/export \"{file}\" {m.Value}"){UseShellExecute=false,CreateNoWindow=true}); exp?.WaitForExit();
        if(exp?.ExitCode==0) MessageBox.Show("Power plan exported:\n"+file); else MessageBox.Show("Power plan export failed. Check Windows permissions and powercfg output.");
    }
    private void RestorePower()
    {
        var files=Directory.GetFiles(AppPaths.Backups,"power-*.pow").OrderByDescending(File.GetLastWriteTimeUtc).ToArray();
        if(files.Length==0){MessageBox.Show("No app-created power scheme backup found.");return;}
        if(MessageBox.Show("Import and activate latest app-created power scheme backup?","Confirm power restore",MessageBoxButton.YesNo,MessageBoxImage.Warning)!=MessageBoxResult.Yes)return;
        var p=Process.Start(new ProcessStartInfo("powercfg.exe",$"/import \"{files[0]}\""){UseShellExecute=false,CreateNoWindow=true}); p?.WaitForExit();
        if(p?.ExitCode!=0){MessageBox.Show("Import failed. The scheme was not activated.");return;}
        var output=Process.Start(new ProcessStartInfo("powercfg.exe","/list"){RedirectStandardOutput=true,UseShellExecute=false,CreateNoWindow=true});
        var text=output?.StandardOutput.ReadToEnd()??""; output?.WaitForExit();
        var id=System.Text.RegularExpressions.Regex.Match(text,@"Power Scheme GUID:\s*([0-9a-fA-F-]{36}).*NEXUS",System.Text.RegularExpressions.RegexOptions.IgnoreCase);
        if(id.Success) Process.Start(new ProcessStartInfo("powercfg.exe",$"/setactive {id.Groups[1].Value}"){UseShellExecute=false,CreateNoWindow=true})?.WaitForExit();
        MessageBox.Show("Backup scheme imported. Verify the active power plan in Windows Settings.");
    }
    private void RunPing()
    {
        var dialog=new Window{Title="Ping diagnostic",Width=400,Height=170,WindowStartupLocation=WindowStartupLocation.CenterOwner,Owner=this,Background=(Brush)FindResource("Panel")};
        var s=new StackPanel{Margin=new Thickness(15)}; var tb=new TextBox{Text="1.1.1.1",Margin=new Thickness(0,0,0,8),Padding=new Thickness(6)}; var b=new Button{Content="Run 10 pings"}; s.Children.Add(new TextBlock{Text="Host or IP address (e.g. a server you trust):",Margin=new Thickness(0,0,0,6)}); s.Children.Add(tb); s.Children.Add(b); dialog.Content=s;
        b.Click+=async (_,_)=>{try{var host=tb.Text.Trim(); if(host.Length==0||host.Length>253)throw new InvalidOperationException("Enter a valid host."); b.IsEnabled=false; var ping=new System.Net.NetworkInformation.Ping(); var ms=new List<long>(); int lost=0; for(int i=0;i<10;i++){try{var r=await ping.SendPingAsync(host,1500);if(r.Status==IPStatus.Success)ms.Add((long)r.RoundtripTime);else lost++;}catch{lost++;}} var avg=ms.Count>0?ms.Average():0; var jitter=ms.Count>1?ms.Zip(ms.Skip(1),(a,c)=>Math.Abs(c-a)).Average():0; MessageBox.Show($"Host: {host}\nReplies: {ms.Count}/10\nLoss: {lost*10}%\nAverage RTT: {(ms.Count>0?avg.ToString("0.0")+" ms":"Unavailable")}\nApprox. successive RTT variation: {(ms.Count>1?jitter.ToString("0.0")+" ms":"Unavailable")}\n\nThis is not Fortnite server ping and ICMP may be deprioritized or blocked.","Ping results");b.IsEnabled=true;}catch(Exception ex){MessageBox.Show(ex.Message);b.IsEnabled=true;}};
        dialog.ShowDialog();
    }
    private void OpenEpic()
    {
        var paths=new[]{Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),"Epic Games","Launcher","Portal","Binaries","Win64","EpicGamesLauncher.exe"),Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),"Epic Games","Launcher","Portal","Binaries","Win64","EpicGamesLauncher.exe")};
        var p=paths.FirstOrDefault(File.Exists);
        if(p!=null) Process.Start(new ProcessStartInfo(p){UseShellExecute=true});
        else Process.Start(new ProcessStartInfo("https://www.epicgames.com/help/en-US/c-Category_EpicGamesStore/c-EpicGamesStore_LauncherSupport/how-to-verify-game-files-in-the-epic-games-launcher-a000084923"){UseShellExecute=true});
        MessageBox.Show("In Epic Games Launcher: Library → Fortnite → three-dot menu → Manage → Verify. Labels may differ by launcher version.");
    }
    private void BuildRestoreCenter()
    {
        AddHeader("Change journal"); var journal=LocalStore.ReadJournal().OrderByDescending(x=>x.Timestamp).ToArray();
        AddText(journal.Length==0?"No app-managed changes recorded yet.":"Only changes recorded by this application are listed below.");
        foreach(var j in journal)
        {
            AddText($"{j.Timestamp.ToLocalTime():g} • {j.Name} • {j.Action} • {j.Result}\n{j.RegistryPath}\\{j.ValueName}: '{j.OldValue ?? "(absent)"}' → '{j.NewValue ?? "(absent)"}'");
        }
        ContentPanel.Children.Add(MakeButton("Undo latest supported capture change",()=>{if(MessageBox.Show("Restore the saved original value if it has not changed externally?","Confirm rollback",MessageBoxButton.YesNo)==MessageBoxResult.Yes)MessageBox.Show(SafeTweakService.UndoLatestCapture());ShowPage("Restore Center");}));
    }
    private void BuildLogs()
    {
        AddHeader("Local storage"); AddText(AppPaths.Root); AddText("No telemetry or diagnostic upload is implemented. The journal and backups stay in the current Windows user's LocalAppData folder.");
        ContentPanel.Children.Add(MakeButton("Export diagnostic report",ExportReport));
        ContentPanel.Children.Add(MakeButton("Open local data folder",()=>Process.Start(new ProcessStartInfo("explorer.exe",AppPaths.Root){UseShellExecute=true})));
        AddHeader("Current capture preference"); AddText(SafeTweakService.ReadCaptureState());
        AddHeader("Journal entries"); foreach(var j in LocalStore.ReadJournal().OrderByDescending(x=>x.Timestamp)) AddText($"{j.Timestamp.ToLocalTime():g} — {j.Name}: {j.Action} / {j.Result}");
    }
    private void BuildProfiles()
    {
        AddHeader("Profiles");
        AddText("Profile saving in this starter build stores a named profile note only. It does not apply a bundle of unsupported tweaks.");
        foreach(var name in new[]{"Competitive Low Latency","Maximum Practical FPS","Balanced Gaming","Laptop Gaming","Custom"})
        {
            var row=new StackPanel{Orientation=Orientation.Horizontal};
            row.Children.Add(new TextBlock{Text=name,Width=280,VerticalAlignment=VerticalAlignment.Center});
            row.Children.Add(MakeButton("Save profile note",()=>{LocalStore.SaveProfile(name,JsonSerializer.Serialize(new { name, created=DateTime.Now, catalogVersion="0.1.0", appliedChanges=LocalStore.ReadJournal().Where(j=>j.Result=="Verified").Select(j=>j.Name).ToArray(), note="Metadata snapshot only; no unsupported settings are applied."},_jsonOptions));MessageBox.Show($"Saved profile metadata for {name}.");}));
            ContentPanel.Children.Add(row);
        }
    }
}
