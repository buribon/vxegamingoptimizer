using Microsoft.Win32;
using System.Diagnostics;
using System.Net.NetworkInformation;
using System.Runtime.InteropServices;
using System.Text.Json;

namespace NEXUSGamingOptimizer;

public static class AppPaths
{
    public static string Root => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "NEXUSGamingOptimizer");
    public static string Journal => Path.Combine(Root, "journal.json");
    public static string Profiles => Path.Combine(Root, "profiles.json");
    public static string Backups => Path.Combine(Root, "backups");
    public static void Ensure() { Directory.CreateDirectory(Root); Directory.CreateDirectory(Backups); }
}
public static class LocalStore
{
    private static readonly JsonSerializerOptions Options = new() { WriteIndented = true };
    public static List<JournalEntry> ReadJournal()
    {
        AppPaths.Ensure();
        try { return JsonSerializer.Deserialize<List<JournalEntry>>(File.ReadAllText(AppPaths.Journal)) ?? new(); } catch { return new(); }
    }
    public static void WriteJournal(List<JournalEntry> entries)
    {
        AppPaths.Ensure();
        File.WriteAllText(AppPaths.Journal, JsonSerializer.Serialize(entries, Options));
    }
    public static void SaveProfile(string name, string content)
    {
        AppPaths.Ensure();
        var file = Path.Combine(AppPaths.Root, "profile-" + SafeName(name) + ".json");
        File.WriteAllText(file, content);
    }
    public static string SafeName(string s) => string.Concat(s.Where(c => char.IsLetterOrDigit(c) || c == '-' || c == '_')).Trim();
}
public static class SystemInspector
{
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
    private class MEMORYSTATUSEX
    {
        public uint dwLength = (uint)Marshal.SizeOf(typeof(MEMORYSTATUSEX));
        public uint dwMemoryLoad;
        public ulong ullTotalPhys, ullAvailPhys, ullTotalPageFile, ullAvailPageFile, ullTotalVirtual, ullAvailVirtual, ullAvailExtendedVirtual;
    }
    [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
    private static extern bool GlobalMemoryStatusEx([In, Out] MEMORYSTATUSEX lpBuffer);
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
    private struct DEVMODE
    {
        private const int CCHDEVICENAME = 32, CCHFORMNAME = 32;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = CCHDEVICENAME)] public string dmDeviceName;
        public short dmSpecVersion, dmDriverVersion, dmSize, dmDriverExtra;
        public int dmFields, dmPositionX, dmPositionY, dmDisplayOrientation, dmDisplayFixedOutput;
        public short dmColor, dmDuplex, dmYResolution, dmTTOption, dmCollate;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = CCHFORMNAME)] public string dmFormName;
        public short dmLogPixels;
        public int dmBitsPerPel, dmPelsWidth, dmPelsHeight, dmDisplayFlags, dmDisplayFrequency;
        public int dmICMMethod, dmICMIntent, dmMediaType, dmDitherType, dmReserved1, dmReserved2, dmPanningWidth, dmPanningHeight;
    }
    [DllImport("user32.dll", CharSet = CharSet.Auto)]
    private static extern bool EnumDisplaySettings(string? deviceName, int modeNum, ref DEVMODE devMode);
    public static HardwareSnapshot Scan()
    {
        var h = new HardwareSnapshot();
        try
        {
            using var k = Registry.LocalMachine.OpenSubKey(@"HARDWARE\DESCRIPTION\System\CentralProcessor\0");
            h.Cpu = (k?.GetValue("ProcessorNameString") as string) ?? Environment.GetEnvironmentVariable("PROCESSOR_IDENTIFIER") ?? "Unavailable";
        } catch {}
        try
        {
            var gpus = new List<string>();
            using var root = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}");
            if (root != null)
                foreach (var sub in root.GetSubKeyNames().Where(x => x.Length == 4 && x.All(char.IsDigit)))
                {
                    using var sk = root.OpenSubKey(sub);
                    var name = sk?.GetValue("DriverDesc") as string;
                    if (!string.IsNullOrWhiteSpace(name) && !name.Contains("Microsoft Basic", StringComparison.OrdinalIgnoreCase)) gpus.Add(name);
                }
            h.Gpu = gpus.Count > 0 ? string.Join("; ", gpus.Distinct()) : "Unavailable";
        } catch {}
        try
        {
            using var k = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows NT\CurrentVersion");
            h.Windows = $"{k?.GetValue("ProductName")} (build {k?.GetValue("CurrentBuildNumber")})";
        } catch {}
        try
        {
            var m = new MEMORYSTATUSEX();
            if (GlobalMemoryStatusEx(m)) h.Ram = $"{m.ullAvailPhys / 1024d / 1024 / 1024:0.0} GB available / {m.ullTotalPhys / 1024d / 1024 / 1024:0.0} GB total ({m.dwMemoryLoad}% used)";
        } catch {}
        try
        {
            var d = DriveInfo.GetDrives().Where(x => x.IsReady && x.DriveType == DriveType.Fixed)
                .Select(x => $"{x.Name} {x.AvailableFreeSpace / 1024d / 1024 / 1024:0} GB free").ToArray();
            h.Disk = d.Length > 0 ? string.Join(" | ", d) : "Unavailable";
        } catch {}
        try
        {
            var dm = new DEVMODE { dmDeviceName = new string(' ', 32), dmFormName = new string(' ', 32) };
            dm.dmSize = (short)Marshal.SizeOf(typeof(DEVMODE));
            if (EnumDisplaySettings(null, -1, ref dm)) h.Display = $"{dm.dmPelsWidth} × {dm.dmPelsHeight} @ {dm.dmDisplayFrequency} Hz (primary display mode)";
        } catch {}
        try
        {
            var psi = new ProcessStartInfo("powercfg.exe", "/getactivescheme") { RedirectStandardOutput = true, UseShellExecute = false, CreateNoWindow = true };
            using var p = Process.Start(psi); string output = p?.StandardOutput.ReadToEnd() ?? ""; p?.WaitForExit(2000);
            h.Power = string.IsNullOrWhiteSpace(output) ? "Unavailable" : output.Trim();
        } catch {}
        try
        {
            var f = Process.GetProcessesByName("FortniteClient-Win64-Shipping").FirstOrDefault();
            h.FortniteRunning = f != null;
            if (f != null) { try { h.FortnitePath = f.MainModule?.FileName ?? "Running (path unavailable)"; } catch { h.FortnitePath = "Running (path access denied)"; } }
            else
            {
                var candidates = new[] {
                    Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "Epic Games", "Fortnite", "FortniteGame", "Binaries", "Win64", "FortniteClient-Win64-Shipping.exe"),
                    Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), "Epic Games", "Fortnite", "FortniteGame", "Binaries", "Win64", "FortniteClient-Win64-Shipping.exe")
                };
                h.FortnitePath = candidates.FirstOrDefault(File.Exists) ?? "Not detected (custom library path may be used)";
            }
        } catch {}
        return h;
    }
    public static string ProcessSummary()
    {
        return string.Join(Environment.NewLine, Process.GetProcesses().OrderByDescending(p => { try { return p.WorkingSet64; } catch { return 0L; } })
            .Take(30).Select(p => { long m=0; try { m=p.WorkingSet64; } catch {} return $"{p.ProcessName,-32} {m/1024d/1024:0} MB"; }));
    }
    public static string StartupSummary()
    {
        var lines = new List<string>();
        foreach (var loc in new[] { (Registry.CurrentUser, @"Software\Microsoft\Windows\CurrentVersion\Run", "HKCU Run"), (Registry.LocalMachine, @"Software\Microsoft\Windows\CurrentVersion\Run", "HKLM Run") })
        {
            try { using var k=loc.Item1.OpenSubKey(loc.Item2); if(k!=null) foreach(var n in k.GetValueNames()) lines.Add($"{loc.Item3}: {n} = {k.GetValue(n)}"); } catch {}
        }
        return lines.Count > 0 ? string.Join(Environment.NewLine, lines) : "No readable Run entries found.";
    }
}
public static class SafeTweakService
{
    private const string CaptureKey = @"Software\Microsoft\Windows\CurrentVersion\GameDVR";
    private const string CaptureValue = "AppCaptureEnabled";
    public static string ReadCaptureState()
    {
        try { using var k=Registry.CurrentUser.OpenSubKey(CaptureKey); var v=k?.GetValue(CaptureValue); return v == null ? "Not explicitly set (Windows default/policy applies)" : $"AppCaptureEnabled = {v}"; }
        catch(Exception ex) { return "Unavailable: " + ex.Message; }
    }
    public static string ToggleCapture(bool enabled)
    {
        AppPaths.Ensure();
        using var key = Registry.CurrentUser.CreateSubKey(CaptureKey, true);
        if (key == null) throw new InvalidOperationException("Could not open the per-user capture key.");
        bool existed = key.GetValueNames().Contains(CaptureValue);
        object? old = key.GetValue(CaptureValue);
        var entry = new JournalEntry { TweakId="NEX-002", Name="Background Game DVR / Capture", Action="Apply", RegistryPath=@"HKCU\" + CaptureKey, ValueName=CaptureValue, ValueExisted=existed, ValueKind=existed ? key.GetValueKind(CaptureValue).ToString() : null, OldValue=old?.ToString(), NewValue=enabled ? "1" : "0" };
        key.SetValue(CaptureValue, enabled ? 1 : 0, RegistryValueKind.DWord);
        var verify = key.GetValue(CaptureValue);
        entry.Result = Convert.ToString(verify) == entry.NewValue ? "Verified" : "Failed verification";
        var journal = LocalStore.ReadJournal(); journal.Add(entry); LocalStore.WriteJournal(journal);
        if (entry.Result != "Verified") throw new InvalidOperationException("Windows did not return the requested value; review the journal.");
        return $"Capture preference set to {(enabled ? "enabled" : "disabled")} and read back successfully. This is a per-user preference; Windows policy or other capture settings may also apply.";
    }
    public static string UndoLatestCapture()
    {
        var journal=LocalStore.ReadJournal();
        var entry=journal.LastOrDefault(x=>x.TweakId=="NEX-002" && x.Action=="Apply" && x.Result=="Verified" && x.RegistryPath==@"HKCU\"+CaptureKey && x.ValueName==CaptureValue);
        if(entry==null) return "No verified app-managed capture change is available to undo.";
        using var key=Registry.CurrentUser.OpenSubKey(CaptureKey,true);
        if(key==null) return "The original registry key is no longer available; nothing was changed.";
        var current=key.GetValue(CaptureValue);
        if(Convert.ToString(current)!=entry.NewValue) return "The setting has changed outside NEXUS since it was applied. For safety, it was not overwritten.";
        if(!entry.ValueExisted) key.DeleteValue(CaptureValue,false);
        else
        {
            var kind=Enum.TryParse<RegistryValueKind>(entry.ValueKind,out var parsed) ? parsed : RegistryValueKind.String;
            object val = entry.OldValue ?? "";
            if(kind==RegistryValueKind.DWord && int.TryParse(entry.OldValue,out var i)) val=i;
            else if(kind==RegistryValueKind.QWord && long.TryParse(entry.OldValue,out var l)) val=l;
            key.SetValue(CaptureValue,val,kind);
        }
        var verify = key.GetValue(CaptureValue);
        bool ok = !entry.ValueExisted ? verify==null : Convert.ToString(verify)==entry.OldValue;
        entry.Action="Undo"; entry.Result=ok ? "Rollback verified" : "Rollback verification failed"; LocalStore.WriteJournal(journal);
        return ok ? "Original value restored and verified." : "Rollback could not be verified. Inspect the journal.";
    }
}
