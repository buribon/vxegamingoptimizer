# Known limitations — 0.1.0

1. The executable has not been compiled in this environment: Linux image, .NET SDK unavailable.
2. All Windows APIs and registry behavior require verification on Windows.
3. The catalog contains 120 unique cards, but only a limited subset has a real operation. Guided cards are labelled accordingly.
4. No frame presentation capture is bundled. FPS, 1%/0.1% lows, frame-time graphs, temperatures, and input latency are not measured.
5. CPU/GPU hardware identification is best-effort and may return unavailable or multiple adapter descriptions.
6. Fortnite discovery checks the running process and two common installation paths; custom installations may not be found.
7. GameUserSettings backup/restore checks the default local config folder only.
8. Power scheme restore imports a saved scheme but its activation path is best-effort; manually verify the active scheme afterward.
9. A basic ICMP test cannot predict actual Fortnite match ping, and ICMP may be blocked/deprioritized.
10. No automated installer, uninstaller, code-signing, third-party hardware sensor integration, or vendor driver control is included.
