using System.Text.Json;
var catalogPath = args.Length > 0 ? args[0] : Path.Combine(AppContext.BaseDirectory, "OptimizationCatalog.json");
if (!File.Exists(catalogPath)) throw new FileNotFoundException("Catalog JSON not found", catalogPath);
using var doc = JsonDocument.Parse(File.ReadAllText(catalogPath));
var cards = doc.RootElement.EnumerateArray().ToArray();
if (cards.Length != 120) throw new Exception($"Expected 120 cards, got {cards.Length}");
var ids = cards.Select(x=>x.GetProperty("id").GetString()).ToArray();
if (ids.Distinct().Count()!=120) throw new Exception("Card IDs must be unique");
foreach (var card in cards)
    foreach (var prop in new[]{"id","category","title","risk","status","description","purpose"})
        if (!card.TryGetProperty(prop,out _)) throw new Exception($"Missing {prop}");
Console.WriteLine("PASS: catalog has 120 cards, unique IDs, and required metadata.");
Console.WriteLine("NOTE: this dependency-free test checks catalog structure only; it does not test Windows APIs.");
