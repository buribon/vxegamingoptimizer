# Technical report: system changes and rollback

## Implemented system modification
- Current-user registry value: `HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR\AppCaptureEnabled`
- Operation: set DWORD 0 or 1 only after user confirmation.
- Before change: record whether the value existed, its registry kind, and its prior value in `%LOCALAPPDATA%\NEXUSGamingOptimizer\journal.json`.
- After change: read back and compare to requested value.
- Rollback: find latest verified app-managed apply; refuse to overwrite if current value no longer matches the app's last value; restore prior value/type or delete it if it was originally absent; read back to verify.
- Limitation: Windows policy, other capture settings, or OS version may affect effective behavior. This operation is not claimed to disable every capture component.

## File changes
- Fortnite `GameUserSettings.ini` backup only copies the existing file.
- Restore copies the current config to a timestamped sibling backup before restoring an app-created backup.
- No direct Fortnite runtime or protected files are modified.

## Power plan
- Backup uses `powercfg /export` on the active scheme.
- Restore imports the exported scheme. Activation is best-effort and must be verified in Windows Settings.

## No broad registry/system tweaks
No arbitrary command execution, undocumented registry tweak bundle, service disabling, security-feature disabling, BCDEdit edits, driver database edits, anti-cheat interaction, or game-memory access is implemented.
