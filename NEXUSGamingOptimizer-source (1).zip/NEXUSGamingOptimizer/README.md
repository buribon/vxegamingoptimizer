# NEXUS Gaming Optimizer — source project (0.1.0)

A Windows desktop starter release for Fortnite-focused diagnostics and reversible configuration. It is **not yet the full production system described in the supplied master prompt**. This package deliberately distinguishes working features from guidance-only cards.

## Environment / executable status

This workspace is Linux-based and has no `dotnet` SDK installed, so I could not compile or launch the Windows WPF `.exe` here. The source project targets **.NET 10 for Windows** and must be built on a Windows machine with the .NET 10 SDK (or an appropriately configured Windows build agent). No compiled `.exe` is included, and this package does not claim a successful build.

## Current implementation

- Native WPF desktop UI (not a browser app), dark theme, sidebar navigation.
- Exactly 120 catalog cards in the categories specified in the master prompt.
- Read-only Windows hardware/status scan for CPU model, GPU descriptions from display-class registry, Windows build, RAM, fixed-drive free space, primary display mode/refresh rate, active power scheme, and Fortnite process/default-path detection.
- Safe Optimize view with an explicitly confirmed, per-user `AppCaptureEnabled` registry preference operation; original value presence, type, and data are journaled; rollback checks for outside changes before restoring.
- Fortnite `GameUserSettings.ini` backup and app-backup restore with a copy of the current file first.
- Power scheme export and a guided restore/import workflow.
- Startup Run-key inventory and process working-set snapshot (read-only).
- Basic 10-packet ICMP latency/loss test to a user-specified destination; it explicitly warns that this is not Fortnite server ping.
- Local diagnostic report export and local journal.
- Manual Epic Launcher verification guidance.
- Local profile metadata files; these are not full system-configuration profiles.

## Not implemented / not verified

- No bundled PresentMon/frame-presentation integration; no real FPS, frame-time, 1% low, 0.1% low, GPU/CPU sensor, or input-latency capture.
- Most of the 120 cards are **Guided / detection only**, not automated tweaks. The UI does not count them as implemented operations.
- No live GPU telemetry, reliable SSD/HDD identification, broad adapter-setting changes, driver-panel automation, automatic session switching, or full profile transaction engine.
- Windows-only APIs and registry operations have not been tested in this environment. NVIDIA/AMD/Intel hardware coverage is unverified.
- The basic WPF project has not been compiled or unit/integration-tested. Review and test it on a disposable Windows test machine before relying on it for system changes.
- The app is not digitally signed. No installer/uninstaller is included in this starter release.

## Build on Windows

1. Install the .NET 10 SDK and Visual Studio 2026 (or a supported Visual Studio version with the .NET desktop workload).
2. Open `src\NEXUSGamingOptimizer\NEXUSGamingOptimizer.csproj`.
3. Build and run in Debug first, preferably in a Windows test VM or non-critical test machine.
4. From PowerShell at the repository root, run `.uild.ps1`.
5. The self-contained x64 output is written to `artifacts\publish\NEXUSGamingOptimizer.exe` if the publish succeeds.

## Safety notes

- The app does not disable Defender, firewall, Memory Integrity, Secure Boot, critical services, anti-cheat, or modify game memory.
- No generic TCP/BCDEdit/timer-resolution/NetworkThrottlingIndex tweaks are applied.
- No FPS gain is guaranteed. Benchmark the same game scene and settings before/after a change.
- App data is stored locally under `%LOCALAPPDATA%\NEXUSGamingOptimizer`.
- Registry rollback is currently implemented only for the capture preference operation.
