# Build status and route to a Windows executable

This project is hosted in a workspace that currently has no .NET SDK, no Windows runtime, and no network/DNS access. Therefore a native Windows WPF executable cannot be compiled or runtime-tested directly here.

A Windows GitHub Actions workflow is included at `.github/workflows/build-windows.yml`. Once the source is pushed to a GitHub repository with Actions enabled, it will:

1. Run a catalog structure test.
2. Publish the WPF app as a self-contained `win-x64` single-file executable.
3. Verify that `NEXUSGamingOptimizer.exe` exists.
4. Package the executable and caveat documentation into a downloadable ZIP artifact.

The workflow verifies build completion, not runtime behavior. The app still needs to be run and tested on a Windows 10/11 PC before being described as production-ready.
