$ErrorActionPreference = "Stop"
$project = Join-Path $PSScriptRoot "src\NEXUSGamingOptimizer\NEXUSGamingOptimizer.csproj"
$publish = Join-Path $PSScriptRoot "artifacts\publish"
New-Item -ItemType Directory -Force -Path $publish | Out-Null
dotnet --info
dotnet publish $project -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -o $publish
if ($LASTEXITCODE -ne 0) { throw "Publish failed with exit code $LASTEXITCODE" }
Write-Host "Published: $publish\NEXUSGamingOptimizer.exe"
